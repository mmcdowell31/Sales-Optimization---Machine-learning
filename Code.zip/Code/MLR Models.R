
df_stlouise <- read.table(file = "/Users/avanijain/Downloads/location_class_stlouis.csv", 
                          sep = ",", header = TRUE)


df_philly <- read.table(file = "/Users/avanijain/Downloads/location_class_philly.csv", 
                        sep = ",", header = TRUE)


df_newyork <- read.table(file = "/Users/avanijain/Downloads/location_class_newyork.csv", 
                         sep = ",", header = TRUE)

df_college <- read.table(file = "/Users/avanijain/Downloads/location_class_college.csv", 
                         sep = ",", header = TRUE)


p_train_data <- df_philly[df_philly$split == "train", ]
P_test_data <- df_philly[df_philly$split == "test", ]

model_philly <- lm(total.sales ~ snow + dayofweek  + total_promotions + tmax + tmin + Annual_Seasonality + Weekly_Seasonality, data = p_train_data)

model_philly_ic <- lm(total.sales ~ snow * total_promotions + dayofweek *  total_promotions + tmax + tmin + Annual_Seasonality + Weekly_Seasonality, data = p_train_data)

summary (model_philly)
summary (model_philly_ic)

predictions_philly <- predict(model_philly, newdata = P_test_data)

average_error_rate <- mean(abs(P_test_data$total.sales - predictions_philly))
print(paste("Average Error Rate:", average_error_rate))

# Calculate Errors
errors <- P_test_data$total.sales - predictions_philly

# Calculate Average Error Variance
average_error_variance <- mean(errors^2)

# Print the Result
print(paste("Average Error Variance:", average_error_variance))


#model for st louise

df_train_stlouise <- df_stlouise[df_stlouise$split == "train", ]
df_test_stlouise <- df_stlouise[df_stlouise$split == "test", ]

model_stl <- lm(total.sales ~ snow + dayofweek  + total_promotions + tmax + tmin + Annual_Seasonality + Weekly_Seasonality, data = df_train_stlouise)


model_stl_ic <- lm(total.sales ~ snow * total_promotions + dayofweek * total_promotions + tmax + tmin + Annual_Seasonality + Weekly_Seasonality, data = df_train_stlouise)
summary(model_stl_ic)

summary (model_stl)


predictions_stl <- predict(model_stl, newdata = df_test_stlouise)

average_error_rate <- mean(abs(df_test_stlouise$total.sales - predictions_stl))
print(paste("Average Error Rate:", average_error_rate))

# Calculate Errors
errors <- df_test_stlouise$total.sales - predictions_stl

# Calculate Average Error Variance
average_error_variance <- mean(errors^2)

# Print the Result
print(paste("Average Error Variance:", average_error_variance))


## model for ny
ny_train_data <- df_newyork[df_newyork$split == "train", ]
ny_test_data <- df_newyork[df_newyork$split == "test", ]

model_ny <- lm(total.sales ~ snow + dayofweek  + total_promotions + tmax + tmin + Annual_Seasonality + Weekly_Seasonality, data = ny_train_data)
summary(model_ny)


predictions_ny <- predict(model_ny, newdata = ny_test_data)

average_error_rate <- mean(abs(ny_test_data$total.sales - predictions_ny))
print(paste("Average Error Rate:", average_error_rate))

# Calculate Errors
errors <- ny_test_data$total.sales - predictions_ny

# Calculate Average Error Variance
average_error_variance <- mean(errors^2)

# Print the Result
print(paste("Average Error Variance:", average_error_variance))


summary (model_ny)

##model for colleges

#College station 

train_data_c <- df_college[df_college$split == "train", ]
test_data_c <- df_college[df_college$split == "test", ]

model_c <- lm(total.sales ~ snow + dayofweek  + total_promotions + tmax + tmin + Annual_Seasonality + Weekly_Seasonality, data = train_data_c)



summary(model_c)

predictions_c <- predict(model_c, newdata = test_data_c)

average_error_rate <- mean(abs(test_data_c$total.sales - predictions_c))
print(paste("Average Error Rate:", average_error_rate))

# Calculate Errors
errors <- test_data_c$total.sales - predictions_c

# Calculate Average Error Variance
average_error_variance <- mean(errors^2)

# Print the Result
print(paste("Average Error Variance:", average_error_variance))


