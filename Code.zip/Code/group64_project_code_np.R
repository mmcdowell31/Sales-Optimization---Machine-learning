
### Setup
library(dplyr)
library(lubridate)
library(tidyr)
library(ggplot2)
library(randomForest)
library(caret)
library(pdp)
library(gridExtra)
library(grid)

set.seed(7406)


### Loading data
store_sales_weather_info <- read.csv("store_sales_weather_info.csv")
new_weather_seasonality <- read.csv("new_weather_seasonality.csv")
DataMining_Marketing <- read.csv("DataMining_Marketing.csv")


### Promotions data prep process
date_sequence <- seq(as.Date("2022-03-23"), as.Date("2025-12-31"), by = "day")
date_df <- data.frame(date = date_sequence)

#Formatting dates and consolidating channel variable values
store_sales_weather_info$date <- as.Date(store_sales_weather_info$date, format="%m/%d/%y")
DataMining_Marketing$Start.Date <- as.Date(DataMining_Marketing$Start.Date, format="%m/%d/%Y")
DataMining_Marketing$End.Date <- as.Date(DataMining_Marketing$End.Date, format="%m/%d/%Y")
DataMining_Marketing$Channels <- gsub("Ecomm ", "Ecomm", DataMining_Marketing$Channels)
DataMining_Marketing <- DataMining_Marketing %>%
  mutate(End.Date = case_when(
    Name == "Free Classic Cookie for January Purchasers" ~ as.Date("2025-02-04"),
    TRUE ~ End.Date
  ))

#Applying marketing data to day rows
promo_date_data <- date_df %>%
  crossing(DataMining_Marketing) %>%
  filter(date >= Start.Date & date <= End.Date) %>%
  mutate(is_active = 1) %>%
  select(date, Name, Type, Channels, Require.Purchase, Segment, Product, is_active, Start.Date, End.Date)



# Create one-hot encoding for the categorical variables
promo_date_data_encoded <- promo_date_data %>%
  mutate(
    type_PointsBonus = ifelse(Type == "Points Bonus", 1, 0),
    type_FreeProduct = ifelse(Type == "Free Product", 1, 0),
    type_ProductDiscount = ifelse(Type == "Product Discount", 1, 0),
    type_FreeDelivery = ifelse(Type == "Free Delivery", 1, 0),
    type_OverallDiscount = ifelse(Type == "Overall Discount", 1, 0),
    
    channel_All = ifelse(Channels == "All", 1, 0),
    channel_Ecomm = ifelse(Channels == "Ecomm", 1, 0),
    channel_InStore = ifelse(Channels == "In-Store", 1, 0),
    channel_DeliveryOnly = ifelse(Channels == "Delivery-Only", 1, 0),
    channel_No = ifelse(Channels == "No", 1, 0),
    channel_AppOnly = ifelse(Channels == "App Only", 1, 0),
    channel_A = ifelse(Channels == "A", 1, 0),
    
    RequirePurchase_Yes = ifelse(Require.Purchase == "Yes", 1, 0),
    
    Segment_AllLoyalty = ifelse(Segment == "All Loyalty", 1, 0),
    Segment_RecentPurchasers = ifelse(Segment == "Recent Purchasers", 1, 0),
    Segment_AllCustomers = ifelse(Segment == "All Customers", 1, 0),
    
    Product_Points = ifelse(Product == "Points", 1, 0),
    Product_LTOs = ifelse(Product == "LTOs", 1, 0),
    Product_FreeDelivery = ifelse(Product == "Free Delivery", 1, 0),
    Product_All = ifelse(Product == "All", 1, 0),
    Product_Delivery = ifelse(Product == "Delivery", 1, 0)
  )

# handling NA where no promotions
daily_promotion_data <- date_df %>%
  left_join(promo_date_data_encoded, by = "date") %>%
  group_by(date) %>%
  summarise(
    total_promotions = sum(is_active, na.rm = TRUE),  
    
    type_PointsBonus = ifelse(all(is.na(type_PointsBonus)), 0, max(type_PointsBonus, na.rm = TRUE)),
    type_FreeProduct = ifelse(all(is.na(type_FreeProduct)), 0, max(type_FreeProduct, na.rm = TRUE)),
    type_ProductDiscount = ifelse(all(is.na(type_ProductDiscount)), 0, max(type_ProductDiscount, na.rm = TRUE)),
    type_FreeDelivery = ifelse(all(is.na(type_FreeDelivery)), 0, max(type_FreeDelivery, na.rm = TRUE)),
    type_OverallDiscount = ifelse(all(is.na(type_OverallDiscount)), 0, max(type_OverallDiscount, na.rm = TRUE)),
    
    channel_All = ifelse(all(is.na(channel_All)), 0, max(channel_All, na.rm = TRUE)),
    channel_Ecomm = ifelse(all(is.na(channel_Ecomm)), 0, max(channel_Ecomm, na.rm = TRUE)),
    channel_InStore = ifelse(all(is.na(channel_InStore)), 0, max(channel_InStore, na.rm = TRUE)),
    channel_DeliveryOnly = ifelse(all(is.na(channel_DeliveryOnly)), 0, max(channel_DeliveryOnly, na.rm = TRUE)),
    channel_No = ifelse(all(is.na(channel_No)), 0, max(channel_No, na.rm = TRUE)),
    channel_AppOnly = ifelse(all(is.na(channel_AppOnly)), 0, max(channel_AppOnly, na.rm = TRUE)),
    channel_A = ifelse(all(is.na(channel_A)), 0, max(channel_A, na.rm = TRUE)),
    
    RequirePurchase_Yes = ifelse(all(is.na(RequirePurchase_Yes)), 0, max(RequirePurchase_Yes, na.rm = TRUE)),
    
    Segment_AllLoyalty = ifelse(all(is.na(Segment_AllLoyalty)), 0, max(Segment_AllLoyalty, na.rm = TRUE)),
    Segment_RecentPurchasers = ifelse(all(is.na(Segment_RecentPurchasers)), 0, max(Segment_RecentPurchasers, na.rm = TRUE)),
    Segment_AllCustomers = ifelse(all(is.na(Segment_AllCustomers)), 0, max(Segment_AllCustomers, na.rm = TRUE)),
    
    Product_Points = ifelse(all(is.na(Product_Points)), 0, max(Product_Points, na.rm = TRUE)),
    Product_LTOs = ifelse(all(is.na(Product_LTOs)), 0, max(Product_LTOs, na.rm = TRUE)),
    Product_FreeDelivery = ifelse(all(is.na(Product_FreeDelivery)), 0, max(Product_FreeDelivery, na.rm = TRUE)),
    Product_All = ifelse(all(is.na(Product_All)), 0, max(Product_All, na.rm = TRUE)),
    Product_Delivery = ifelse(all(is.na(Product_Delivery)), 0, max(Product_Delivery, na.rm = TRUE))
  )

#Joinging promotions data tot weather data
daily_promotion_sales_data <- store_sales_weather_info %>%
  left_join(daily_promotion_data, by = "date") %>%
  left_join(sales_seasonality, by = c("date", "store_id"))

#cleaning for rows missing promotion data
columns_to_factor <- c("store_id", "store", "type", "dayofweek")
daily_promotion_sales_data[columns_to_factor] <- lapply(daily_promotion_sales_data[columns_to_factor], as.factor)
filtered_daily_promotion_sales_data <- daily_promotion_sales_data %>%
  filter(date >= "2024-02-25" & !store %in% c("Fishtown", "Hempstead", "IWP Flagship"))

#Joining sales to seasonality data with imputed values
new_weather_seasonality <- new_weather_seasonality %>%
  rename(
    prcp = PRCP,
    snow = SNOW,
    tmax = TMAX,
    tmin = TMIN,
    store_id = Store_ID
  )
new_weather_seasonality$date <-  as.Date(new_weather_seasonality$date)
new_weather_seasonality$store_id <- as.factor(new_weather_seasonality$store_id)
filtered_daily_promotion_sales_data <- filtered_daily_promotion_sales_data %>% 
  select(-prcp, -snow, -tmax, -tmin, -Annual_Seasonality, -Weekly_Seasonality)

sales_data_join_new <- filtered_daily_promotion_sales_data %>%
  left_join(new_weather_seasonality %>% select("date", "store_id", "prcp", "snow", "tmax", "tmin",
                                               "Annual_Seasonality", "Weekly_Seasonality"),
            by = c("date", "store_id"))


### Split Sales data by location type
sales_data_join_new_no_na <- sales_data_join_new %>%
  na.omit()

sales_data_join_new_no_na <- sales_data_join_new_no_na %>%
  rename(
    location_class = type
  )

sales_data_join_new_no_na <- sales_data_join_new_no_na %>%
  mutate(location_class = case_when(
    location_class == "Ann Arbor" ~ "College",
    location_class == "Oxford" ~ "College",
    location_class == "State College" ~ "College",
    TRUE ~ location_class  # Keep other values unchanged
  ))

sales_data_join_new_no_na <- sales_data_join_new_no_na %>% 
  select(-number, -store)

split_dfs <- list()
# Split data by location_class
for (location in unique(sales_data_join_new_no_na$location_class)) {
  
  df_sub <- sales_data_join_new_no_na %>% filter(location_class == location)
  
  # Generate the 80/20 split for train/test
  df_sub <- df_sub %>%
    mutate(
      split = ifelse(runif(nrow(df_sub)) < 0.8, "train", "test")
    )
  
  # Save the resulting data frame to the list
  split_dfs[[location]] <- df_sub
}



###Creating EDA plot of correlation matrix
excluded_columns <- c("date", "total.sales", "number", "store_id", "store", "type", "dayofweek")
non_numeric_columns <- sapply(filtered_daily_promotion_sales_data, function(x) !is.numeric(x))
names(filtered_daily_promotion_sales_data)[non_numeric_columns]

correlations <- sapply(filtered_daily_promotion_sales_data[, setdiff(names(filtered_daily_promotion_sales_data), excluded_columns)], 
                       function(x) cor(x, filtered_daily_promotion_sales_data$total.sales))
cor_df <- data.frame(variable = names(correlations), correlation = correlations)
ggplot(cor_df, aes(x = variable, y = correlation, fill = correlation)) +
  geom_bar(stat = "identity", color = "black") +
  labs(title = "Correlation of Predictors with Target Variable", 
       x = "Predictor Variables", 
       y = "Correlation Value") +
  theme_minimal() +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", midpoint = 0)

top_10_corr_df <- cor_df %>%
  mutate(abs_correlation = abs(correlation)) %>%
  arrange(desc(abs_correlation)) %>%
  head(10)

ggplot(top_10_corr_df, aes(x = reorder(variable, correlation), y = correlation, fill = correlation)) +
  geom_bar(stat = "identity", color = "black") +
  labs(title = "Top 10 Correlations with the Target Variable", 
       x = "Predictor Variables", 
       y = "Correlation Value") +
  theme_minimal() +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", midpoint = 0) +
  coord_flip() 


###St Louis Random Forest model
stlouis_rf_data <- split_dfs$'St Louis' %>%
  select(-all_of(c("date", "store_id", "location_class")))

train_stlouis_rf_data <- stlouis_rf_data[stlouis_rf_data$split == "train", ]  %>%
  select(-"split")
test_stlouis_rf_data <- stlouis_rf_data[stlouis_rf_data$split == "test", ]  %>%
  select(-"split")

tune_grid_rf <- expand.grid(mtry = seq(15, 30, 1))
train_control <- trainControl(method = "cv", 
                              number = 5,  # 5-fold cv
                              search = "grid")  # Use grid search

rf_stl_grid <- train(total.sales ~ ., data = train_stlouis_rf_data, 
                     method = "rf",
                     trControl = train_control,
                     tuneGrid = tune_grid_rf) 

# tuning parameters
print(rf_stl_grid$bestTune) #26
print(rf_stl_grid$results)

# Plotted hyperparameter performance
plot(rf_stl_grid)
predictions <- predict(rf_stl_grid, newdata = test_stlouis_rf_data)

## Testing Error
predictions <- predict(rf_stl_grid,newdata = test_stlouis_rf_data[,-1])
actual_values <- test_stlouis_rf_data[,1]
stl_r2 <- cor(predictions, actual_values) ^ 2
stl_r2
rf_testerr <- mean(predictions - actual_values) # Mean error = 26.9713
rf_testerr

rss <- sum((predictions - actual_values) ^ 2)  # Residual Sum of Squares
tss <- sum((actual_values - mean(actual_values)) ^ 2)  # Total Sum of Squares
explained_variance <- 1 - (rss / tss)
explained_variance

mae <- mean(abs(predictions - actual_values))
mae

avg_err_rate <- mean(predictions - actual_values)
avg_err_rate

avg_error_variance <- var(predictions - actual_values)/length(predictions)
avg_error_variance


###Philly Random Forest model
philly_rf_data <- split_dfs$'Philly' %>%
  select(-all_of(c("date", "store_id", "location_class")))

train_philly_rf_data <- philly_rf_data[philly_rf_data$split == "train", ]  %>%
  select(-"split")
test_philly_rf_data <- philly_rf_data[philly_rf_data$split == "test", ]  %>%
  select(-"split")


tune_grid_rf <- expand.grid(mtry = seq(15, 30, 1))
train_control <- trainControl(method = "cv", 
                              number = 5,  # 5-fold cv
                              search = "grid")  # Use grid search

rf_phl_grid <- train(total.sales ~ ., data = train_philly_rf_data, 
                     method = "rf",
                     trControl = train_control,
                     tuneGrid = tune_grid_rf) 

# tuning parameters
print(rf_phl_grid$bestTune) #30

print(rf_phl_grid$results)

# Plotted hyperparameter performance
plot(rf_phl_grid)

## Testing Error
predictions <- predict(rf_phl_grid,newdata = test_philly_rf_data[,-1])
actual_values <- test_philly_rf_data[,1]

rss <- sum((predictions - actual_values) ^ 2)  # Residual Sum of Squares
tss <- sum((actual_values - mean(actual_values)) ^ 2)  # Total Sum of Squares
explained_variance <- 1 - (rss / tss)
explained_variance

mae <- mean(abs(predictions - actual_values))
mae

avg_err_rate <- mean(predictions - actual_values)
avg_err_rate

avg_error_variance <- var(predictions - actual_values)/length(predictions)
avg_error_variance


### College RF model
college_rf_data <- split_dfs$'College' %>%
  select(-all_of(c("date", "store_id", "location_class")))

train_college_rf_data <- college_rf_data[college_rf_data$split == "train", ]  %>%
  select(-"split")
test_college_rf_data <- college_rf_data[college_rf_data$split == "test", ]  %>%
  select(-"split")

tune_grid_rf <- expand.grid(mtry = seq(15, 30, 1))
train_control <- trainControl(method = "cv", 
                              number = 5,  # 5-fold cv
                              search = "grid")  # Use grid search

rf_college_grid <- train(total.sales ~ ., data = train_college_rf_data, 
                         method = "rf",
                         trControl = train_control,
                         tuneGrid = tune_grid_rf) 

# tuning parameters
print(rf_college_grid$bestTune) #26

print(rf_college_grid$results)

# Plotted hyperparameter performance
plot(rf_college_grid)

## Testing Error
predictions <- predict(rf_college_grid,newdata = test_college_rf_data[,-1])
actual_values <- test_college_rf_data[,1]

rss <- sum((predictions - actual_values) ^ 2)  # Residual Sum of Squares
tss <- sum((actual_values - mean(actual_values)) ^ 2)  # Total Sum of Squares
explained_variance <- 1 - (rss / tss)
explained_variance

mae <- mean(abs(predictions - actual_values))
mae

avg_err_rate <- mean(predictions - actual_values)
avg_err_rate

avg_error_variance <- var(predictions - actual_values)/length(predictions)
avg_error_variance


###New York Random Forest model
ny_rf_data <- split_dfs$'New York' %>%
  select(-all_of(c("date", "store_id", "location_class")))

train_ny_rf_data <- ny_rf_data[ny_rf_data$split == "train", ]  %>%
  select(-"split")
test_ny_rf_data <- ny_rf_data[ny_rf_data$split == "test", ]  %>%
  select(-"split")

tune_grid_rf <- expand.grid(mtry = seq(15, 30, 1))
train_control <- trainControl(method = "cv", 
                              number = 5,  # 5-fold cv
                              search = "grid")  # Use grid search

rf_ny_grid <- train(total.sales ~ ., data = train_ny_rf_data, 
                    method = "rf",
                    trControl = train_control,
                    tuneGrid = tune_grid_rf) 

# tuning parameters
print(rf_ny_grid$bestTune) #16

print(rf_ny_grid$results)

# Plotted hyperparameter performance
plot(rf_ny_grid)

# Testing Error
predictions <- predict(rf_ny_grid,newdata = test_ny_rf_data[,-1])
actual_values <- test_ny_rf_data[,1]

rss <- sum((predictions - actual_values) ^ 2)  # Residual Sum of Squares
tss <- sum((actual_values - mean(actual_values)) ^ 2)  # Total Sum of Squares
explained_variance <- 1 - (rss / tss)
explained_variance

mae <- mean(abs(predictions - actual_values))
mae

avg_err_rate <- mean(predictions - actual_values)
avg_err_rate

avg_error_variance <- var(predictions - actual_values)/length(predictions)
avg_error_variance


###Graph optimal mtry across models
rf_ny_mtry <- rf_ny_grid$results[, c("mtry", "RMSE")]
rf_college_mtry <- rf_college_grid$results[, c("mtry", "RMSE")]
rf_phl_mtry <- rf_phl_grid$results[, c("mtry", "RMSE")]
rf_stl_mtry <- rf_stl_grid$results[, c("mtry", "RMSE")]

#labels
rf_ny_mtry$Model <- "NY"
rf_college_mtry$Model <- "College"
rf_phl_mtry$Model <- "Philly"
rf_stl_mtry$Model <- "St. Louis"

combined_mtry <- rbind(rf_ny_mtry, rf_college_mtry, rf_phl_mtry, rf_stl_mtry)

ggplot(combined_mtry, aes(x = mtry, y = RMSE, color = Model, group = Model)) +
  geom_line() + 
  geom_point() +  
  labs(title = "Optimal mtry and RMSE for Location Models",
       x = "Sampled Variables (mtry)",
       y = "Root Mean Squared Error (RMSE)") +
  theme_minimal() +
  theme(legend.position = "top")


### Partial dependence plots
# partial dependence data for tmax and promo - STL
pd_stl <- partial(rf_stl_grid, pred.var = c("tmax", "total_promotions"))

# Plot with color palette & convex hull
rwb <- colorRampPalette(c("blue", "white", "red"))
pdp_stl <- plotPartial(pd_stl, col.regions = rwb, 
                       xlab="Max Temperature (F)", ylab = "Total Active Promotions",
                       main="St Louis Locations - PDP for Total Sale")
# partial dependence data for tmax and promo - PHL
pd_phl <- partial(rf_phl_grid, pred.var = c("tmax", "total_promotions"))
pdp_phl <- plotPartial(pd_phl, col.regions = rwb, 
                       xlab="Max Temperature (F)", ylab = "Total Active Promotions",
                       main="Philly Locations - PDP for Total Sale")
# partial dependence data for tmax and rm - college
pd_college <- partial(rf_college_grid, pred.var = c("tmax", "total_promotions"))
pdp_college <- plotPartial(pd_college, col.regions = rwb, 
                           xlab="Max Temperature (F)", ylab = "Total Active Promotions",
                           main="College Locations - PDP for Total Sales ($)")
# partial dependence data for tmax and rm - NY
pd_ny <- partial(rf_ny_grid, pred.var = c("tmax", "total_promotions"))
pdp_ny <- plotPartial(pd_ny, col.regions = rwb, 
                      xlab="Max Temperature (F)", ylab = "Total Active Promotions",
                      main="New York Locations - PDP for Total Sales ($)")
promo_stl <- partial(rf_stl_grid, pred.var = "total_promotions", plot = FALSE)
promo_phl <- partial(rf_phl_grid, pred.var = "total_promotions", plot = FALSE)
promo_college <- partial(rf_college_grid, pred.var = "total_promotions", plot = FALSE)
promo_ny <- partial(rf_ny_grid, pred.var = "total_promotions", plot = FALSE)

pdp_stl <- plotPartial(promo_stl, main = "St Louis", xlab = "Total Promotions", ylab = "Total Sales ($)")
pdp_phl <- plotPartial(promo_phl, main = "Philly", xlab = "Total Promotions", ylab = "Total Sales ($)")
pdp_college <- plotPartial(promo_college, main = "College", xlab = "Total Promotions", ylab = "Total Sales ($)")
pdp_ny <- plotPartial(promo_ny, main = "New York", xlab = "Total Promotions", ylab = "Total Sales ($)")
grid.arrange(pdp_stl, pdp_phl, pdp_college, pdp_ny, ncol = 2)


### Variable importance plot
imp_stl <- varImp(rf_stl_grid, scale = TRUE)$importance
imp_phl <- varImp(rf_phl_grid, scale = TRUE)$importance
imp_college <- varImp(rf_college_grid, scale = TRUE)$importance
imp_ny <- varImp(rf_ny_grid, scale = TRUE)$importance

imp_stl$Model <- "St Louis"
imp_phl$Model <- "Philly"
imp_college$Model <- "College"
imp_ny$Model <- "New York"

# Combining importance data into one data frame
imp_combined <- rbind(
  data.frame(Variable = rownames(imp_stl), Importance = imp_stl[, 1], Model = "St Louis"),
  data.frame(Variable = rownames(imp_phl), Importance = imp_phl[, 1], Model = "Philly"),
  data.frame(Variable = rownames(imp_college), Importance = imp_college[, 1], Model = "College"),
  data.frame(Variable = rownames(imp_ny), Importance = imp_ny[, 1], Model = "New York")
)

# top 10 variables based on overall importance
top_10 <- imp_combined %>%
  group_by(Variable) %>%
  summarise(Average_Importance = mean(Importance)) %>%
  arrange(desc(Average_Importance)) %>%
  head(10)

# Filtering combined data to only the top 10
top_10_combined <- imp_combined %>%
  filter(Variable %in% top_10$Variable)

# Plotting the top 10 variable importance
ggplot(top_10_combined, aes(x = reorder(Variable, Importance), y = Importance, fill = Model)) +
  geom_bar(stat = "identity", position = "dodge") +
  coord_flip() +
  labs(title = "Variable Importance for Location Type Models", 
       x = "Variables", 
       y = "Scaled Importance") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
